<?php $__env->startSection('title', 'Dashboard'); ?>
<?php if (isset($component)) { $__componentOriginal69e6671d1f4b7f5c91f45b64fedb8965 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69e6671d1f4b7f5c91f45b64fedb8965 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="p-5 2xl:mx-0 mx-2 bg-gradient-to-bl from-green-600 to-transparent rounded-xl border-2">
        <div class="flex space-x-3 items-center">
            <div class="bg-white h-16 w-16 relative shadow-lg rounded-full overflow-hidden">
                <img src="<?php echo e(asset('images/sample.png')); ?>" class="h-full w-full object-cover " alt="">
            </div>
            <div>
                <h1 class="uppercase font-bold text-lg text-gray-700 underline"><?php echo e(auth()->user()->name); ?></h1>
                <h1 class="uppercase text-sm font-semibold text-gray-500">
                    <?php echo e(auth()->user()->user_type); ?>(<?php echo e(auth()->user()->identification); ?>)</h1>
            </div>
        </div>
    </div>
    <div
        class="p-5 2xl:mx-0 mx-2 border-2 bg-white bg-opacity-80 border-green-600 mt-5 rounded-xl flex justify-center items-center">
        <div>
            <?php echo e(QrCode::size(250)->generate(auth()->user()->identification)); ?>

        </div>
    </div>
    <div class="mt-5 mx-4 2xl:mx-0">
        <header class="font-bold text-xl text-green-600">VEHICLE INFORMATION</header>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('user.edit-detail', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-790057329-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <div class="mt-4 grid grid-cols-2 gap-5">
            <div>
                <h1 class="text-sm">Model</h1>
                <h1 class="uppercase text-lg text-gray-700 font-bold"><?php echo e(auth()->user()->vehicleInformation->model); ?>

                </h1>
            </div>
            <div>
                <h1 class="text-sm">Plate Number</h1>
                <h1 class="uppercase text-lg text-gray-700 font-bold">
                    <?php echo e(auth()->user()->vehicleInformation->plate_number); ?></h1>
            </div>
            <div>
                <h1 class="text-sm">ORCR</h1>
                <div class="flex space-x-2 items-center">
                    <h1 class="uppercase text-lg text-gray-700 font-bold">
                        <?php echo e(auth()->user()->vehicleInformation->orcr); ?></h1>
                    <a href="<?php echo e(Storage::url(auth()->user()->vehicleInformation->proof_of_orcr)); ?>" target="_blank">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="h-5 w-5 text-green-600"
                            fill="currentColor">
                            <path
                                d="M10 6V8H5V19H16V14H18V20C18 20.5523 17.5523 21 17 21H4C3.44772 21 3 20.5523 3 20V7C3 6.44772 3.44772 6 4 6H10ZM21 3V11H19L18.9999 6.413L11.2071 14.2071L9.79289 12.7929L17.5849 5H13V3H21Z">
                            </path>
                        </svg>
                    </a>
                </div>
            </div>
            <div>
                <h1 class="text-sm">License Number</h1>
                <div class="flex space-x-2 items-center">
                    <h1 class="uppercase text-lg text-gray-700 font-bold">
                        <?php echo e(auth()->user()->vehicleInformation->license); ?></h1>
                    <a href="<?php echo e(Storage::url(auth()->user()->vehicleInformation->proof_of_license)); ?>" target="_blank">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="h-5 w-5 text-green-600"
                            fill="currentColor">
                            <path
                                d="M10 6V8H5V19H16V14H18V20C18 20.5523 17.5523 21 17 21H4C3.44772 21 3 20.5523 3 20V7C3 6.44772 3.44772 6 4 6H10ZM21 3V11H19L18.9999 6.413L11.2071 14.2071L9.79289 12.7929L17.5849 5H13V3H21Z">
                            </path>
                        </svg>
                    </a>
                </div>
            </div>
        </div>

        <div class="w-full">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('user.vehicle-update', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-790057329-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69e6671d1f4b7f5c91f45b64fedb8965)): ?>
<?php $attributes = $__attributesOriginal69e6671d1f4b7f5c91f45b64fedb8965; ?>
<?php unset($__attributesOriginal69e6671d1f4b7f5c91f45b64fedb8965); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69e6671d1f4b7f5c91f45b64fedb8965)): ?>
<?php $component = $__componentOriginal69e6671d1f4b7f5c91f45b64fedb8965; ?>
<?php unset($__componentOriginal69e6671d1f4b7f5c91f45b64fedb8965); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\PROJECTS\VehicleSecuritySystem\resources\views/user/index.blade.php ENDPATH**/ ?>