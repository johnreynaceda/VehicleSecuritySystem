<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <style>
        [x-cloak] {
            display: none !important;
        }
    </style>
    <?php echo WireUi::directives()->scripts(attributes: []); ?>

    <?php echo \Filament\Support\Facades\FilamentAsset::renderStyles() ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>

<body class="font-sans antialiased">
    <?php if (isset($component)) { $__componentOriginal1a98e8493fe28b42b3b0e4055c45bff9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a98e8493fe28b42b3b0e4055c45bff9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.shared.background','data' => ['class' => 'h-[90rem] fixed -right-96 -top-60 2xl:opacity-100 opacity-30']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('shared.background'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-[90rem] fixed -right-96 -top-60 2xl:opacity-100 opacity-30']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a98e8493fe28b42b3b0e4055c45bff9)): ?>
<?php $attributes = $__attributesOriginal1a98e8493fe28b42b3b0e4055c45bff9; ?>
<?php unset($__attributesOriginal1a98e8493fe28b42b3b0e4055c45bff9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a98e8493fe28b42b3b0e4055c45bff9)): ?>
<?php $component = $__componentOriginal1a98e8493fe28b42b3b0e4055c45bff9; ?>
<?php unset($__componentOriginal1a98e8493fe28b42b3b0e4055c45bff9); ?>
<?php endif; ?>
    <div class="bg-white border-b relative">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('navbar', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1982367929-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
    <main class="mx-auto max-w-7xl 2xl:py-10 py-5 relative">
        <header class="font-bold 2xl:text-3xl text-2xl mx-2 2xl:mx-0 text-green-600 uppercase"><?php echo $__env->yieldContent('title'); ?>
        </header>
        <div class="2xl:mt-10 mt-5">
            <?php echo e($slot); ?>

        </div>
    </main>
    <?php echo \Filament\Support\Facades\FilamentAsset::renderScripts() ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\PROJECTS\VehicleSecuritySystem\resources\views/components/user-layout.blade.php ENDPATH**/ ?>