<div>
    <div class="mt-10 grid 2xl:grid-cols-3 2xl:gap-5 gap-2 grid-cols-1">
        <div class="border border-gray-600 relative h-40 overflow-hidden rounded-xl border-dashed p-4">
            <img src="<?php echo e(Storage::url(auth()->user()->vehicleInformation->front_view_path)); ?>"
                class="h-full w-full absolute left-0 top-0 object-cover" alt="">
            <div class="absolute bottom-0 left-0 bg-white px-3 py-2 bg-opacity-80 w-full">
                <span class="font-bold text-gray-700 uppercase">Front View</span>
            </div>
            <div class="absolute right-2 top-2">
                <?php if (isset($component)) { $__componentOriginal472ea0eb8f0535afe9ab76636937c0a8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal472ea0eb8f0535afe9ab76636937c0a8 = $attributes; } ?>
<?php $component = WireUi\View\Components\CircleButton::resolve(['icon' => 'pencil-alt','spinner' => 'updateView(\'front_view\')'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button.circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\CircleButton::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['positive' => true,'wire:click' => 'updateView(\'front_view\')']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal472ea0eb8f0535afe9ab76636937c0a8)): ?>
<?php $attributes = $__attributesOriginal472ea0eb8f0535afe9ab76636937c0a8; ?>
<?php unset($__attributesOriginal472ea0eb8f0535afe9ab76636937c0a8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal472ea0eb8f0535afe9ab76636937c0a8)): ?>
<?php $component = $__componentOriginal472ea0eb8f0535afe9ab76636937c0a8; ?>
<?php unset($__componentOriginal472ea0eb8f0535afe9ab76636937c0a8); ?>
<?php endif; ?>
            </div>
        </div>
        <div class="border border-gray-600 relative h-40 overflow-hidden rounded-xl border-dashed p-4">
            <img src="<?php echo e(Storage::url(auth()->user()->vehicleInformation->back_view_path)); ?>"
                class="h-full w-full absolute left-0 top-0 object-cover" alt="">
            <div class="absolute bottom-0 left-0 bg-white px-3 py-2 bg-opacity-80 w-full">
                <span class="font-bold text-gray-700 uppercase">Back View</span>
            </div>
            <div class="absolute right-2 top-2">
                <?php if (isset($component)) { $__componentOriginal472ea0eb8f0535afe9ab76636937c0a8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal472ea0eb8f0535afe9ab76636937c0a8 = $attributes; } ?>
<?php $component = WireUi\View\Components\CircleButton::resolve(['icon' => 'pencil-alt','spinner' => 'updateView(\'back_view\')'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button.circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\CircleButton::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['positive' => true,'wire:click' => 'updateView(\'back_view\')']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal472ea0eb8f0535afe9ab76636937c0a8)): ?>
<?php $attributes = $__attributesOriginal472ea0eb8f0535afe9ab76636937c0a8; ?>
<?php unset($__attributesOriginal472ea0eb8f0535afe9ab76636937c0a8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal472ea0eb8f0535afe9ab76636937c0a8)): ?>
<?php $component = $__componentOriginal472ea0eb8f0535afe9ab76636937c0a8; ?>
<?php unset($__componentOriginal472ea0eb8f0535afe9ab76636937c0a8); ?>
<?php endif; ?>
            </div>
        </div>
        <div class="border border-gray-600 relative h-40 overflow-hidden rounded-xl border-dashed p-4">
            <img src="<?php echo e(Storage::url(auth()->user()->vehicleInformation->side_view_path)); ?>"
                class="h-full w-full absolute left-0 top-0 object-cover" alt="">
            <div class="absolute bottom-0 left-0 bg-white px-3 py-2 bg-opacity-80 w-full">
                <span class="font-bold text-gray-700 uppercase">Side View</span>
            </div>
            <div class="absolute right-2 top-2">
                <?php if (isset($component)) { $__componentOriginal472ea0eb8f0535afe9ab76636937c0a8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal472ea0eb8f0535afe9ab76636937c0a8 = $attributes; } ?>
<?php $component = WireUi\View\Components\CircleButton::resolve(['icon' => 'pencil-alt','spinner' => 'updateView(\'side_view\')'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button.circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\CircleButton::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['positive' => true,'wire:click' => 'updateView(\'side_view\')']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal472ea0eb8f0535afe9ab76636937c0a8)): ?>
<?php $attributes = $__attributesOriginal472ea0eb8f0535afe9ab76636937c0a8; ?>
<?php unset($__attributesOriginal472ea0eb8f0535afe9ab76636937c0a8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal472ea0eb8f0535afe9ab76636937c0a8)): ?>
<?php $component = $__componentOriginal472ea0eb8f0535afe9ab76636937c0a8; ?>
<?php unset($__componentOriginal472ea0eb8f0535afe9ab76636937c0a8); ?>
<?php endif; ?>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal7ea8362733ae9e02c43079506217fb0f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7ea8362733ae9e02c43079506217fb0f = $attributes; } ?>
<?php $component = WireUi\View\Components\Modal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.defer' => 'open_modal']); ?>
        <?php if (isset($component)) { $__componentOriginal526977d3da1dbf047bef54116d3416a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal526977d3da1dbf047bef54116d3416a0 = $attributes; } ?>
<?php $component = WireUi\View\Components\Card::resolve(['title' => ''.e($view_get).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Card::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <div>
                <?php
                    $view = null;
                    switch ($view_get) {
                        case 'front_view':
                            $view = auth()->user()->vehicleInformation->front_view_path;
                            break;

                        case 'back_view':
                            $view = auth()->user()->vehicleInformation->back_view_path;
                            break;
                        case 'side_view':
                            $view = auth()->user()->vehicleInformation->side_view_path;
                            break;

                        default:
                            # code...
                            break;
                    }
                ?>

                <img src="<?php echo e(Storage::url($view)); ?>" class="h-40 w-96 object-cover" alt="">
                <div class="mt-5">
                    <?php echo e($this->form); ?>

                </div>
            </div>

             <?php $__env->slot('footer', null, []); ?> 
                <div class="flex justify-end gap-x-4">
                    <?php if (isset($component)) { $__componentOriginal53cf851b4d6af185b0b5e0467ca69b92 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53cf851b4d6af185b0b5e0467ca69b92 = $attributes; } ?>
<?php $component = WireUi\View\Components\Button::resolve(['flat' => true,'label' => 'Cancel'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-on:click' => 'close']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53cf851b4d6af185b0b5e0467ca69b92)): ?>
<?php $attributes = $__attributesOriginal53cf851b4d6af185b0b5e0467ca69b92; ?>
<?php unset($__attributesOriginal53cf851b4d6af185b0b5e0467ca69b92); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53cf851b4d6af185b0b5e0467ca69b92)): ?>
<?php $component = $__componentOriginal53cf851b4d6af185b0b5e0467ca69b92; ?>
<?php unset($__componentOriginal53cf851b4d6af185b0b5e0467ca69b92); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal53cf851b4d6af185b0b5e0467ca69b92 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53cf851b4d6af185b0b5e0467ca69b92 = $attributes; } ?>
<?php $component = WireUi\View\Components\Button::resolve(['spinner' => 'updateRecord','label' => 'Update Record'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['dark' => true,'wire:click' => 'updateRecord']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53cf851b4d6af185b0b5e0467ca69b92)): ?>
<?php $attributes = $__attributesOriginal53cf851b4d6af185b0b5e0467ca69b92; ?>
<?php unset($__attributesOriginal53cf851b4d6af185b0b5e0467ca69b92); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53cf851b4d6af185b0b5e0467ca69b92)): ?>
<?php $component = $__componentOriginal53cf851b4d6af185b0b5e0467ca69b92; ?>
<?php unset($__componentOriginal53cf851b4d6af185b0b5e0467ca69b92); ?>
<?php endif; ?>
                </div>
             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal526977d3da1dbf047bef54116d3416a0)): ?>
<?php $attributes = $__attributesOriginal526977d3da1dbf047bef54116d3416a0; ?>
<?php unset($__attributesOriginal526977d3da1dbf047bef54116d3416a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal526977d3da1dbf047bef54116d3416a0)): ?>
<?php $component = $__componentOriginal526977d3da1dbf047bef54116d3416a0; ?>
<?php unset($__componentOriginal526977d3da1dbf047bef54116d3416a0); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7ea8362733ae9e02c43079506217fb0f)): ?>
<?php $attributes = $__attributesOriginal7ea8362733ae9e02c43079506217fb0f; ?>
<?php unset($__attributesOriginal7ea8362733ae9e02c43079506217fb0f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ea8362733ae9e02c43079506217fb0f)): ?>
<?php $component = $__componentOriginal7ea8362733ae9e02c43079506217fb0f; ?>
<?php unset($__componentOriginal7ea8362733ae9e02c43079506217fb0f); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\PROJECTS\VehicleSecuritySystem\resources\views/livewire/user/vehicle-update.blade.php ENDPATH**/ ?>