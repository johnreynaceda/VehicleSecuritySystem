@section('title', 'Dashboard')
<x-admin-layout>
    <div>
        <livewire:guard.transaction />
    </div>
</x-admin-layout>
