@section('title', 'Attendance')
<x-admin-layout>
    <div>
        <livewire:admin.attendance-list />
    </div>
</x-admin-layout>
