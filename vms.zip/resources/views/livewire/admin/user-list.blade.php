<div>
    <div class="bg-white p-5 rounded-lg bg-opacity-50 shadow">
        {{ $this->table }}
    </div>
</div>
