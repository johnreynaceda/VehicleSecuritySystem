@section('title', 'Home')
<x-admin-layout>
    <div>
        <livewire:guard.transaction />
    </div>
</x-admin-layout>
