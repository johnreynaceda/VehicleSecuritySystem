<img src="{{ asset('images/sksu_logo.png') }}" {{ $attributes }} alt="">
